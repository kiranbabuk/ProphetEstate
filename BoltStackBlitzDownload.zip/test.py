print("Python version test")

# Test basic functionality
def add(a, b):
    return a + b

result = add(5, 3)
print(f"5 + 3 = {result}")

# Test standard library imports
import sys
print(f"Python version: {sys.version}")